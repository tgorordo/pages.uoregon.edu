# -*- coding: utf-8 -*-
# homework5.py
"""
Author:   Raghuveer Parthasarathy
Last modified on Oct. 23, 2024

Description
-----------
Scripts for image analysis homework 5
Also used for part of HW6
"""

import numpy as np
import matplotlib.pyplot as plt
import scipy.special as scipy_special  # scipy is too big to import all of it.
import time # for HW6

#%% 1 The Signal-to-Noise Ratio in Images. 

# Code version

Nx = 1000 # number of X values
nA = 50 # number of A values
min_log10A = -6
max_log10A = 6
A = np.logspace(min_log10A, max_log10A, num=nA)
A_rep = np.tile(A, (Nx, 1))

x = np.random.gamma(2.0, size = (Nx, nA))

mean_over_std_x = np.mean(x, axis=0) / np.std(x, axis=0)
mean_over_std_Ax = np.mean(A_rep*x, axis=0) / np.std(A_rep*x, axis=0)

ratio_mean = np.mean(mean_over_std_x / mean_over_std_Ax)
ratio_std = np.std(mean_over_std_x / mean_over_std_Ax)

print(f'mean(ratio) +/- std(ratio) = {ratio_mean:.4e} +/- {ratio_std:.4e}')


#%% 2 Centroid warmup

x = np.arange(1000)
I = 0.2*(x**0.5)
xc = np.sum(x*I)/np.sum(I)
print(f'(i) xc = {xc:.2f}')

x = np.arange(1000)
I = 30 / (x+20) + 0.05*np.random.poisson(10, x.shape)
xc = np.sum(x*I)/np.sum(I)
print(f'(ii) xc = {xc:.2f}')


#%% Simulated image function


# I'll recopy the HW4 function here to 
# make sure I'm consistent with what students are doing


def simPointSource(N, scale=0.1, fineScale = 0.01, NA = 0.9, 
                   lam = 0.53, Nphoton = 1000, xc = 0, yc = 0, 
                   bkgPoissMean=0, makeFigures=False):
    """
    Function to create a simulated point source image: PSF, pixelation, noise
    Returns a square 2D array, NxN, normalized to sum==Nphoton.
    Inputs:
       N : final camera image array size (N x N pixels)
       scale : final camera scale, um/px
       fineScale: microns / pixel for high-resolution PSF
       NA : numerical aperture
       lam : free-space wavelength of light, *microns*
       Nphoton : number of photons, total; rescale output to sum to this
       xc, yc : point source center location, *microns*
       bkgPoissMean : mean per-pixel background intensity
       makeFigures : if true, show fine PSF
     Output: 
       simImage : NxN integer array, simulated image, photons at each px.
   """
    scaleMultiplier = scale / fineScale
    # Check that it's an integer multiple
    if np.abs(scaleMultiplier % 1) > 0.01:
        print('Warning! camera scale is not an integer multiple of the fine scale')
        print(f'Original scaleMultiplier: {scaleMultiplier:.3e}')
        fineScale = scale / np.round(scaleMultiplier)
        print(f'Changing fineScale to be {fineScale:.3e}')
    else:
        scaleMultiplier = np.round(scaleMultiplier)
    
    # High-resolution PSF
    # Could call my PSF function, but I'll make this self-contained.
    N_fine = np.int(N*scaleMultiplier) # pixels for the fine array
    # High-resolution PSF
    x1D = fineScale*np.arange(-(N_fine-1)/2,(N_fine+1)/2) - xc
    y1D = fineScale*np.arange(-(N_fine-1)/2,(N_fine+1)/2) - yc
    x, y = np.meshgrid(x1D, y1D)  # grid positions, microns
    rpositions = np.sqrt(x*x + y*y);  # matrix of distances from the center, in microns
    v = (2*np.pi/lam)*NA*rpositions;  # array of 'v' values    
    psf = 4*(scipy_special.j1(v)/v)**2
    psf[v==0]=1 # Correct the undefined central value
    if makeFigures:
        plt.figure()
        plt.imshow(psf, cmap='gray')
        plt.title('Fine resolution')
    
    # Pixelate
    simImage = np.zeros((N, N))
    for j in range(N):
        for k in range(N):
            j_range = np.arange(j*scaleMultiplier, (j+1)*scaleMultiplier).astype(int)
            k_range = np.arange(k*scaleMultiplier, (k+1)*scaleMultiplier).astype(int)
            simImage[j,k] = np.sum(psf[j_range, k_range])    
    
    # Rescale so that the total intensity is Nphoton
    simImage = Nphoton*simImage / np.sum(simImage)
    
    # Photon noise
    # Draw the intensity values from a Poisson distribution for each pixel
    # Note: integer values
    simImage = np.random.poisson(simImage, simImage.shape); 
    
    # Add Poisson background
    if bkgPoissMean > 0:
        im_bkg = np.random.poisson(bkgPoissMean, simImage.shape) # Background
        simImage += im_bkg

    return simImage

#%% 3 Centroid localization

def centroid2D(im):
    # Calculates the centroid of a 2D array
    # Input:
    #    im : 2D image array
    # Output
    #    (xc, yc) : centroid, pixels, relative to center
    Nx = im.shape[1]
    Ny = im.shape[0]
    x = np.arange(Nx) - (Nx-1)/2
    y = np.arange(Ny) - (Ny-1)/2
    xx, yy = np.meshgrid(x, y)
    xc = np.sum(xx*im)/np.sum(im)
    yc = np.sum(yy*im)/np.sum(im)
    return (xc, yc)

def calc_RMSE(x0, y0, xc, yc):
    # calculates RMSE of 2D positions
    # Inputs:
        # x0, y0 : true x and y positions
        # xc, yc : arrays of estimated x and y positions
    # Output:
        # RMSE, in whatever units the inputs are in
    RMSE = np.sqrt(np.mean((xc-x0)**2 + (yc-y0)**2))
    return RMSE
    
# Example
N = 11 # Size of the simulated image, NxN Pixels
scale = 0.1 # camera scale, microns/px
lam = 0.5 # wavelength of light, microns
NA = 0.9 # NA
Nphoton = 2000 # total number of photons

x0 = 0.04 # x-offset, microns
y0 = 0.0 # y-offset, microns

bkgPoissMean = 2 # Mean of additive Poisson background

im = simPointSource(N, scale, fineScale = scale/20, 
                    NA=NA, lam=lam, Nphoton=Nphoton, xc=x0, yc=y0, 
                    bkgPoissMean=bkgPoissMean)

(xc, yc) = centroid2D(im)
print('example: ', xc, yc)

#%% 3(a)

# Simulated images
N = 11 # Size of the simulated image, NxN Pixels
scale = 0.1 # camera scale, microns/px
lam = 0.51 # wavelength of light, microns
NA = 0.9 # NA
Nphoton = 1000 # total number of photons

x0 = 0.0 # x-offset, microns
y0 = 0.0 # y-offset, microns

bkgPoissMean = 10 # Mean of additive Poisson background


M = 100 # number of simulated images
im =  np.zeros((N, N, M), dtype=float)

for j in range(M):
    im[:,:,j] = simPointSource(N, scale, fineScale = scale/50, 
                    NA=NA, lam=lam, Nphoton=Nphoton, xc=x0, yc=y0, 
                    bkgPoissMean=bkgPoissMean)

xc = np.zeros((M,1))
yc = np.zeros((M,1))

tic = time.perf_counter()
for j in range(M):
    xcyc = centroid2D(im[:,:,j])
    # Centroid, and convert to real units
    xc[j] = xcyc[0]*scale # microns
    yc[j] = xcyc[1]*scale
toc = time.perf_counter()
elapsed_time = toc-tic
print(f"Centroid time per image  = {elapsed_time/M:0.5f} seconds")
RMSE = calc_RMSE(x0, y0, xc, yc)
print(f'RMSE: {RMSE:0.5f} microns')

plt.figure()
plt.hist(xc)
plt.xlabel('xc, microns')
plt.ylabel('Number of occurrences')
plt.title(f'Centroid xc, {M} images, {Nphoton} photons')

# For (c)
plt.figure()
plt.hist((xc-x0)/scale)
plt.xlabel('Error in xc, pixels')
plt.ylabel('Number of occurrences')
plt.title(f'Centroid x error, {Nphoton} photons, x0 = {x0/scale:.3f} px')
plt.xlim(-0.5, 0.5)

#%% (b)	A range of Nphoton from 4 to 4000

# Simulated images

# total number of photons
Nphoton_array = np.logspace(np.log10(40), np.log10(40000), num=20) 
x0 = 0.0 # x-offset, microns
y0 = 0.0 # y-offset, microns

M = 100 # number of simulated images at each Nphoton

RMSE = np.zeros((len(Nphoton_array),1))
for k in range(len(Nphoton_array)):
    print(f'{k}: Nphoton = {Nphoton_array[k]:.1f}')
    im =  np.zeros((N, N, M), dtype=float)
    
    # Simulated images
    for j in range(M):
        im[:,:,j] = simPointSource(N, scale, fineScale = scale/50, 
                        NA=NA, lam=lam, Nphoton=Nphoton_array[k], xc=x0, yc=y0, 
                        bkgPoissMean=bkgPoissMean)

    xc = np.zeros((M,1))
    yc = np.zeros((M,1))
    for j in range(M):
        xcyc = centroid2D(im[:,:,j])
        # Centroid, and convert to real units
        xc[j] = xcyc[0]*scale
        yc[j] = xcyc[1]*scale
    RMSE[k] = calc_RMSE(x0, y0, xc, yc)

plt.figure()
plt.scatter(Nphoton_array, RMSE*1000, s=60)
plt.plot(Nphoton_array, 300/np.sqrt(Nphoton_array))
plt.ylabel('RMSE, nm')
plt.xlabel('Number of photons')
plt.title(f'Centroid RMSE, {M} images at each Nphoton')
plt.yscale('log')
plt.xscale('log')

#%% (c)

# Use the same code as in (a)

#%% (d) 

p_array = np.linspace(-0.5, 0.5, num=11)

# total number of photons
Nphoton = 1000 

# Mean of additive Poisson background
bkgPoissMean = 10

M = 10 # number of simulated images at each Nphoton

meanDx = np.zeros((len(p_array),1))
for k in range(len(p_array)):
    x0 = p_array[k]*scale # x-offset, microns
    y0 = p_array[k]*scale # y-offset, microns
    print(f'{k}: x0 = {x0:.3f}')
    im =  np.zeros((N, N, M), dtype=float)
    
    # Simulated images
    for j in range(M):
        im[:,:,j] = simPointSource(N, scale, fineScale = scale/50, 
                        NA=NA, lam=lam, Nphoton=Nphoton, xc=x0, yc=y0, 
                        bkgPoissMean=bkgPoissMean)
        
    xc = np.zeros((M,1))
    yc = np.zeros((M,1))
    for j in range(M):
        xcyc = centroid2D(im[:,:,j])
        # Centroid, and convert to real units
        xc[j] = xcyc[0]*scale
        yc[j] = xcyc[1]*scale
    meanDx[k] = np.mean(xc-x0)

plt.figure()
plt.scatter(p_array, meanDx/scale, s=120)
plt.xlabel('x offset, px')
plt.ylabel('Delta x, px')
plt.title(f'{Nphoton} Photons; Background {bkgPoissMean:.1f}')
plt.xlim(-0.60, 0.60)
plt.ylim(-0.60, 0.60)
